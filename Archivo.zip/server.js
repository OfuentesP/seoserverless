import express from 'express';
import cors from 'cors';
import puppeteer from 'puppeteer';
import { SitemapStream } from 'sitemap';
import { Readable } from 'stream';
import fetch from 'node-fetch';
import { streamToPromise } from 'sitemap';
import axios from 'axios';
import WebPageTest from 'webpagetest';

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

const WEBPAGETEST_BASE_URL = 'https://www.webpagetest.org/runtest.php';
const WEBPAGETEST_RESULTS_URL = 'https://www.webpagetest.org/jsonResult.php';

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

// WebPageTest API Proxy
app.get('/api/webpagetest/runtest', async (req, res) => {
  try {
    const { url, apiKey } = req.query;

    if (!url || !apiKey) {
      return res.status(400).json({ error: 'URL and API key are required' });
    }

    console.log('Starting WebPageTest analysis for:', url);
    console.log('Using API key:', apiKey);
    
    // Build the request URL with the API key in the correct format
    const params = new URLSearchParams({
      url: url,
      k: apiKey,
      f: 'json',
      lighthouse: '1',
      mobile: '1',
      location: 'ec2-us-east-1:Chrome',
      runs: '1',
      video: '1',
      timeline: '1'
    });

    const requestUrl = `${WEBPAGETEST_BASE_URL}?${params.toString()}`;
    console.log('Making request to:', requestUrl);

    const response = await axios.get(requestUrl, {
      headers: {
        'Accept': 'application/json'
      }
    });

    console.log('WebPageTest response:', response.data);

    if (response.data.statusCode === 200) {
      console.log('WebPageTest test started successfully');
      res.json(response.data);
    } else {
      console.error('WebPageTest API error:', response.data);
      res.status(response.data.statusCode || 400).json({
        error: response.data.statusText || 'Error running WebPageTest',
        details: response.data
      });
    }
  } catch (error) {
    console.error('Error running WebPageTest:', error.response?.data || error);
    const status = error.response?.status || 500;
    const message = error.response?.data?.statusText || error.message;
    
    res.status(status).json({ 
      error: 'Error running WebPageTest',
      details: message,
      response: error.response?.data
    });
  }
});

// WebPageTest Results Proxy
app.get('/api/webpagetest/results', async (req, res) => {
  try {
    const { test, apiKey } = req.query;

    if (!test || !apiKey) {
      return res.status(400).json({ error: 'Test ID and API key are required' });
    }

    console.log('Fetching WebPageTest results for test ID:', test);

    const params = {
      test: test,
      k: apiKey,
      f: 'json',
      lighthouse: 1
    };

    console.log('Making request to WebPageTest API with params:', params);

    const response = await axios({
      method: 'get',
      url: WEBPAGETEST_RESULTS_URL,
      params: params,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log('WebPageTest results response:', response.data);

    if (response.data.statusCode === 200) {
      res.json(response.data);
    } else if (response.data.statusCode === 100) {
      // Test is still running
      res.json(response.data);
    } else {
      res.status(response.data.statusCode || 400).json({
        error: response.data.statusText || 'Error getting test results',
        details: response.data
      });
    }
  } catch (error) {
    console.error('Error getting WebPageTest results:', error.response?.data || error);
    const status = error.response?.status || 500;
    const message = error.response?.data?.statusText || error.message;

    res.status(status).json({ 
      error: 'Error getting test results',
      details: message,
      response: error.response?.data
    });
  }
});

// Metadata Analysis
app.get('/api/metadata/analyze', async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    console.log('Starting metadata analysis for:', url);
    const browser = await puppeteer.launch({ 
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'networkidle0', timeout: 60000 });

    const metadata = await page.evaluate(() => {
      const getMetaContent = (name) => {
        const meta = document.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
        return meta ? meta.getAttribute('content') : null;
      };

      return {
        title: document.title,
        description: getMetaContent('description'),
        keywords: getMetaContent('keywords'),
        ogTitle: getMetaContent('og:title'),
        ogDescription: getMetaContent('og:description'),
        ogImage: getMetaContent('og:image'),
        twitterCard: getMetaContent('twitter:card'),
        twitterTitle: getMetaContent('twitter:title'),
        twitterDescription: getMetaContent('twitter:description'),
        canonical: document.querySelector('link[rel="canonical"]')?.href,
        h1Tags: Array.from(document.querySelectorAll('h1')).map(h1 => h1.textContent.trim()),
        otherMetaTags: Array.from(document.querySelectorAll('meta')).map(meta => ({
          name: meta.getAttribute('name') || meta.getAttribute('property'),
          content: meta.getAttribute('content')
        })).filter(meta => meta.name && !['description', 'keywords'].includes(meta.name))
      };
    });

    await browser.close();
    console.log('Metadata analysis completed');
    res.json(metadata);
  } catch (error) {
    console.error('Metadata error:', error);
    res.status(500).json({ error: error.message || 'Error analyzing metadata' });
  }
});

// Sitemap Analysis
app.get('/api/sitemap/analyze', async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    console.log('Starting sitemap analysis for:', url);
    const baseUrl = new URL(url).origin;
    const sitemapUrl = `${baseUrl}/sitemap.xml`;

    console.log('Fetching sitemap from:', sitemapUrl);
    try {
      const response = await fetch(sitemapUrl);
      if (!response.ok) {
        if (response.status === 404) {
          return res.json({ 
            error: 'Sitemap no encontrado', 
            message: 'El sitio no tiene un archivo sitemap.xml en la raíz.',
            sitemapUrl,
            status: 404
          });
        }
        throw new Error(`Failed to fetch sitemap: ${response.statusText}`);
      }

      const sitemapXml = await response.text();
      const stream = new Readable();
      stream.push(sitemapXml);
      stream.push(null);

      const sitemap = await streamToPromise(new SitemapStream());
      
      const urls = sitemap.map(entry => ({
        loc: entry.url,
        lastmod: entry.lastmod,
        changefreq: entry.changefreq,
        priority: entry.priority
      }));

      const results = {
        totalUrls: urls.length,
        validUrls: urls.filter(url => url.loc).length,
        invalidUrls: urls.length - urls.filter(url => url.loc).length,
        urls,
        issues: []
      };

      if (results.invalidUrls > 0) {
        results.issues.push({
          title: 'URLs inválidas detectadas',
          description: `Se encontraron ${results.invalidUrls} URLs que no son válidas.`
        });
      }

      if (urls.some(url => !url.lastmod)) {
        results.issues.push({
          title: 'Fechas de modificación faltantes',
          description: 'Algunas URLs no tienen fecha de última modificación.'
        });
      }

      console.log('Sitemap analysis completed');
      res.json(results);
    } catch (error) {
      console.error('Sitemap error:', error);
      res.status(500).json({ error: error.message || 'Error analyzing sitemap' });
    }
  } catch (error) {
    console.error('Sitemap error:', error);
    res.status(500).json({ error: error.message || 'Error analyzing sitemap' });
  }
});

// AI Analysis
app.get('/api/ai/analyze', async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    console.log('Starting AI analysis for:', url);
    // Simulación de análisis de IA
    const aiResults = {
      contentQuality: {
        score: 85,
        analysis: 'El contenido es relevante y bien estructurado.'
      },
      recommendations: [
        'Considerar agregar más imágenes descriptivas',
        'Mejorar la densidad de palabras clave',
        'Agregar más enlaces internos'
      ],
      keywordAnalysis: [
        { term: 'principal', relevance: 90 },
        { term: 'secundaria', relevance: 75 },
        { term: 'terciaria', relevance: 60 }
      ]
    };

    console.log('AI analysis completed');
    res.json(aiResults);
  } catch (error) {
    console.error('AI analysis error:', error);
    res.status(500).json({ error: error.message || 'Error in AI analysis' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
}); 
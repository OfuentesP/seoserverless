<script setup>
import { ref, computed } from 'vue'
import MetadataAnalysis from './components/MetadataAnalysis.vue'
import AIAnalysis from './components/AIAnalysis.vue'
import SitemapAnalysis from './components/SitemapAnalysis.vue'
import WebPageTest from './components/WebPageTest.vue'

const url = ref('')
const loading = ref(false)
const error = ref('')

// Results state
const metadataResults = ref(null)
const sitemapResults = ref(null)
const aiResults = ref(null)

const isValidUrl = computed(() => {
  try {
    new URL(url.value)
    return true
  } catch {
    return false
  }
})

const analyzeUrl = async () => {
  if (!isValidUrl.value) return

  // Reset results
  metadataResults.value = null
  sitemapResults.value = null
  aiResults.value = null

  try {
    // Start metadata analysis
    loading.value = true
    error.value = ''
    const metadataResponse = await fetch(`/api/metadata/analyze?url=${encodeURIComponent(url.value)}`)
    if (!metadataResponse.ok) throw new Error('Error al analizar metadatos')
    metadataResults.value = await metadataResponse.json()
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }

  try {
    // Start sitemap analysis
    loading.value = true
    error.value = ''
    const sitemapResponse = await fetch(`/api/sitemap/analyze?url=${encodeURIComponent(url.value)}`)
    if (!sitemapResponse.ok) throw new Error('Error al analizar sitemap')
    sitemapResults.value = await sitemapResponse.json()
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }

  try {
    // Start AI analysis
    loading.value = true
    error.value = ''
    const aiResponse = await fetch(`/api/ai/analyze?url=${encodeURIComponent(url.value)}`)
    if (!aiResponse.ok) throw new Error('Error en el análisis de IA')
    aiResults.value = await aiResponse.json()
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8">
    <div class="max-w-7xl mx-auto">
      <h1 class="text-4xl font-bold mb-8">Análisis SEO y Rendimiento</h1>

      <!-- URL Input -->
      <div class="mb-8">
        <div class="flex gap-4">
          <input
            v-model="url"
            type="url"
            placeholder="https://ejemplo.com"
            class="flex-1 bg-white/10 rounded px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            @click="analyzeUrl"
            class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded transition-colors"
            :disabled="!isValidUrl"
          >
            Analizar
          </button>
        </div>
      </div>

      <div v-if="url && isValidUrl" class="space-y-8">
        <!-- WebPageTest Analysis -->
        <WebPageTest :url="url" />

        <!-- Metadata Analysis -->
        <MetadataAnalysis :metadata-results="metadataResults" :loading="loading" :error="error" />

        <!-- Sitemap Analysis -->
        <SitemapAnalysis :sitemap-results="sitemapResults" :loading="loading" :error="error" />

        <!-- AI Analysis -->
        <AIAnalysis :ai-results="aiResults" :loading="loading" :error="error" />
      </div>
    </div>
  </div>
</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>

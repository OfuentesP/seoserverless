<template>
  <div v-if="lighthouse" class="mt-12 mx-auto max-w-3xl p-8 bg-white rounded-2xl shadow-2xl animate-fadeIn">
    <h2 class=" mt-5 pt-5 text-3xl font-extrabold text-green-700 mb-8 text-center tracking-tight flex items-center justify-center gap-2">
      <span>📊</span> Auditoría Lighthouse
    </h2>
    <div class="grid grid-cols-12 sm:grid-cols-12 md:grid-cols-13 gap-6 mb-10">
      <div v-for="(cat, key) in lighthouseCategorias" :key="key" class="bg-gradient-to-br from-blue-50 to-white p-6 rounded-xl shadow text-center border border-blue-100">
        <p class="text-lg font-semibold text-gray-800 flex items-center justify-center gap-2">{{ cat.emoji }} {{ cat.nombre }}</p>
        <p v-if="lighthouse.categories && lighthouse.categories[key]" class="text-3xl font-extrabold text-blue-600 mt-2">
          {{ (lighthouse.categories[key].score * 100).toFixed(0) }} / 100
        </p>
        <p v-else class="text-gray-400">No disponible</p>
      </div>
    </div>
    <div v-if="lighthouse.audits" class="mt-10">
      <h3 class="text-2xl font-bold text-blue-800 mb-6 text-center flex items-center gap-2 justify-center">
        <span>📝</span> Detalles de la auditoría
      </h3>
      <div class="grid grid-cols-1 gap-4 max-h-[420px] overflow-y-auto pr-2">
        <div v-for="(audit, key) in lighthouse.audits" :key="key" class="p-5 border rounded-lg bg-gray-50 shadow-sm">
          <h4 class="font-bold text-lg text-gray-800 mb-1">{{ audit.title }}</h4>
          <p class="text-sm text-gray-600 mb-2">{{ audit.description }}</p>
          <p>
            <span class="font-semibold">Puntuación:</span>
            <span :class="getScoreClass(audit.score)">
              {{ (audit.score * 100).toFixed(0) }} / 100
            </span>
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { watch } from 'vue';
const props = defineProps({
  lighthouse: Object,
  lighthouseCategorias: Object,
  getScoreClass: Function
});
watch(() => props.lighthouse, (val) => {
  if (val) console.log('[LighthouseResults] Mostrando datos Lighthouse:', val);
});
</script> 